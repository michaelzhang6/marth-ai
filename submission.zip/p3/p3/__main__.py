import p3.p3

p3.p3.main()
