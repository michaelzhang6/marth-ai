# OpenAI-Melee-
Run with python -m p3 before opening Dolphin. Stop with ^C.

Location of Dolphin files on Mac:
/Users/michaelzhang/library/application support/dolphin

replace 'michaelzhang' with name of user

controller in dolphin needs to be configured to pipe 3